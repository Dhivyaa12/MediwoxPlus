import apiClient from './index';

export const getDoctors = async () => {
  const res = await apiClient.get('/doctors');
  return res.data;
};
