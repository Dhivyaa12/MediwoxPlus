// src/services/firebase/firebaseConfig.ts

import { initializeApp } from "firebase/app";
import { getAuth, RecaptchaVerifier } from "firebase/auth";

// ✅ Your Firebase config from your latest message
const firebaseConfig = {
  apiKey: "AIzaSyBuM3xEh6ONyCRjJHCNVME8ktz6VqQCP-I",
  authDomain: "mediwoxplus.firebaseapp.com",
  projectId: "mediwoxplus",
  storageBucket: "mediwoxplus.firebasestorage.app",
  messagingSenderId: "533642642025",
  appId: "1:533642642025:web:c8848fba8531da0d9b98f8",
  measurementId: "G-6DE5V4LQRN",
};

// ✅ Initialize Firebase app
const app = initializeApp(firebaseConfig);

// ✅ Export auth object
export const auth = getAuth(app);

// ✅ Function to set up reCAPTCHA before sending OTP
export const setupRecaptcha = () => {
  if (!window.recaptchaVerifier) {
    window.recaptchaVerifier = new RecaptchaVerifier(auth, "recaptcha-container", {
      size: "invisible",
      callback: (response: any) => {
        console.log("reCAPTCHA resolved:", response);
      },
    });
  }
};

// ✅ Global declaration to avoid TypeScript errors
declare global {
  interface Window {
    recaptchaVerifier: RecaptchaVerifier;
  }
}